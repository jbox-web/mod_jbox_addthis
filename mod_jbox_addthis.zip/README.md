JBox AddThis SmartLayer module for Joomla (v1.0)
================
This little Joomla module will help you with handling JBox AddThis Smartlayer ! It embeds all the needed scripts and code, and let you manage everything just with simple forms ! No code to add : install it and make it work quick.

Features
========
* Active share buttons
* Active follow buttons
* Allows you to configure Responsive Design parameters
* Allows you to manage differents social networks

More informations on http://www.addthis.com

Installation
================
1. Download module files
2. Create a ZIP archive with the files
3. Send to Joomla's extensions manager
4. Finished ! A new module instance is now created in your modules list !

Copyright & Licence
====================
Copyright (c) 2014 Lior Chamla (lchamla@jbox-web.com), JBox Web (http://www.jbox-web.com), GPL Licence

More help
=========
Find more informations on **how to set-up a great AddThis SmartLayer** here : http://support.addthis.com/customer/portal/articles/1200473-smart-layers-api
